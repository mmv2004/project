﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq;

namespace c4_20
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int max = 0, pred = -1, count = 1;
            string first="",second="";
            for (int i = 0; i < n; i++)
            {
                string[] s = Console.ReadLine().Split();
                if (s[2] == "50")
                {
                    
                    if (int.Parse(s[3]) < max && int.Parse(s[3]) > pred)
                    {
                        pred = int.Parse(s[3]);
                        second=s[0]+" "+s[1];
                    }
                    if (int.Parse(s[3]) == max)
                    {
                        count++;
                    }
                    if (int.Parse(s[3]) > max)
                    {
                         max = int.Parse(s[3]);
                            first=s[0]+" "+s[1];
                        count=1;
                    }
                }

            }
            if (count == 1)
            {
                Console.WriteLine(first);
                Console.WriteLine(second);
            }
            else
            {
                Console.WriteLine(count);
            }
            Console.ReadLine();
        }
    }
}
