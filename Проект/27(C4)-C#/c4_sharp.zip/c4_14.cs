﻿using System;
using System.Collections.Generic;
using System.Text;

namespace c4
{
    class Program
    {
        static void Main(string[] args)
        {
            string n = Console.ReadLine();
           char[] a = n.ToCharArray();
           char[] b = new char[n.Length]; 
           Array.Sort(a);
           int k = -1;
           bool f = false;
           for (int i = 0; i < a.Length-1; i+=2)
           {
                   if (a[i] == a[i + 1])
                   {
                       k++;
                       b[k] = a[i];
                       b[b.Length - k - 1] = a[i];
                   }
                   else
                   {
                       if (f)
                           break;
                       b[b.Length/2] = a[i];
                       i--;
                       f = true;
                   }
               
           }

           if (k < n.Length / 2-1)
               Console.WriteLine("no");
           else
           for (int i = 0; i < b.Length; i++)
          {
               Console.Write(b[i]);
          }

        
           
           Console.ReadLine();
        }
    }
}
