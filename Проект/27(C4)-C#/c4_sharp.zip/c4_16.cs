﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] t = Console.ReadLine().Split(':');
            int hour = int.Parse(t[0]);
            int min = int.Parse(t[1]);

            int count = 0;
            int n = int.Parse(Console.ReadLine());

            string[] names = new string[n];
            for (int i = 0; i < n; i++)
            {
                string[] s = Console.ReadLine().Split(' ');
                string[] s2 = s[1].Split(':');

                if ((int.Parse(s2[0]) - hour <= 2) && (int.Parse(s2[1])<=min))
                {
                    names[count] = int.Parse(s2[0]) + " " + s[0];
                    count++;
                }
                if ((int.Parse(s2[0]) - hour < 2) && (int.Parse(s2[1]) > min))
                {
                    names[count] = int.Parse(s2[0]) + " " +s[0];
                    count++;
                } 
            }
            Array.Sort(names);
            for (int i = 1; i < names.Length; i++)
            {
                try{string[] s = names[i].Split(' ');
                    Console.WriteLine(s[1]);} catch { }
            }

            Console.Read();


        }
    }
}
