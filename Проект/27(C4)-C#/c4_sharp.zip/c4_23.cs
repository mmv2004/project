﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace c4_23
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int predel = (n / 100) * 20;
            int[] ball = new int[n];
            for (int i = 0; i < n; i++)
            {
                string[] s = Console.ReadLine().Split(' ');
                ball[i] = int.Parse(s[3]);
            }
            Array.Sort(ball);
            int k=ball[n-1];
            for (int i = n; i > ball.Length - predel+1; i--)
            {
                if (ball[i] != ball[ball.Length - predel])
                {
                    k=ball[ball.Length - predel];
                }
            }
            Console.WriteLine(k);
            Console.Read();
        }
    }
}
