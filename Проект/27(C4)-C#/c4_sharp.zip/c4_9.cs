﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int predel = (n / 100) * 20;
            int count=1,max=0;
            string rezult = "";
            bool flag = false;
            for (int i = 0; i < n; i++)
            {
                string[] s = Console.ReadLine().Split(' ');

                if (int.Parse(s[3]) == max)
                {
                    count++;
                    if (count > predel)
                    {
                        flag = true;
                    }
                    
                }
                if (int.Parse(s[3]) > max && int.Parse(s[3]) > 200)
                {
                    max = int.Parse(s[3]);
                    rezult = s[0] + " " + s[1];
                    count = 1;
                }
                

            }

            if (count == 1 && flag==false && max>200)
            {
                Console.WriteLine(rezult);
            }
            if (count != 1 && flag == false && max>200)
            {
                Console.WriteLine(count);
            }
            if (max == 0 | flag == true)
            {
                Console.WriteLine("no");
            }
            Console.Read();
           
        }
    }
}
