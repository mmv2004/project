﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication5
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine()),count = 0;
            string[] bad = new string[n];
            for(int i=0;i<n;i++)
            {
                string[] s = Console.ReadLine().Split(' ');
                if (int.Parse(s[2]) < 30 && int.Parse(s[3]) < 30)
                {
                    bad[count] = s[0] + " " + s[1];
                    count++;
                }
            }
            Array.Sort(bad);
            for (int i = 0; i < bad.Length; i++)
            {
                Console.WriteLine(bad[i]);
            }
            Console.Read();

        }
    }
}
