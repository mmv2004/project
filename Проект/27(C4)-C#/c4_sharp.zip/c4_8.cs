﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            string[] phone = new string[n];
            for (int i = 0; i < n; i++)
            {
                string[] s = Console.ReadLine().Split(' ');
                string[] ss = s[2].Split('-');
                phone[i] = ss[2];
            }

            Array.Sort(phone);
            
            int count = 1, count2 = 1;

            for (int i = 0; i < n-1; i++)
            {
                 if (phone[i] != phone[i+1])
                    {
                        count2++;
                    }
                   
            }
            
            Console.WriteLine("Количество сотрудников= "+phone.Length);
            Console.WriteLine("Количество подразделений= "+count2);

            Console.WriteLine("Среднее количество сотрудников= " + ((double)phone.Length / count2).ToString());
            Console.Read();
        }
    }
}
