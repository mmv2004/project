﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace c4_11
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] ball = new int[n];
            int[] winers = new int[11];
            int predel = (n / 100) * 25;
            for (int i = 0; i < n; i++)
            {
                string[] s = Console.ReadLine().Split(' ');
                ball[i] = int.Parse(s[3]);
                winers[int.Parse(s[2])]++;
            }
            Array.Sort(ball);
            if (ball[n - predel] == ball[n - predel + 1] && ball[n - predel] > 35)
            {
                Console.Write(ball[n - predel]);
            }
            if (ball[n - predel] == ball[n - predel + 1] && ball[n - predel] <= 35)
            {
                for (int i = ball[n - predel]; i < n; i++)
                {
                    if (ball[i] != ball[n - predel])
                    {
                        Console.WriteLine(ball[i]);
                        break;
                    }
                }
            }
            if (ball[n - predel] != ball[n - predel + 1])
            {
                Console.Write(ball[n - predel]);
            }
            Console.WriteLine(winers[6]);
            Console.WriteLine(winers[7]);
            Console.WriteLine(winers[8]);
            Console.WriteLine(winers[9]);
            Console.WriteLine(winers[10]);
            Console.ReadLine();
        }
    }
}
