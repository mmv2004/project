﻿using System;
using System.Collections.Generic;
using System.Text;

namespace с4_19
{
    class Program
    {
        static void Main(string[] args)
        {

            int n = int.Parse(Console.ReadLine());
            string b = "";
            int miny = 2101, minm = 13, mind = 32,count=1;
            for (int i = 0; i < n; i++)
            {
                string[] s1 = Console.ReadLine().Split(' ');
                string[] s = s1[2].Split('.');
               

                if(int.Parse(s[2]) <= miny)
                {
                    if (int.Parse(s[2]) == miny)
                    {
                       if(int.Parse(s[1]) == minm)
                       {

                           if (int.Parse(s[0]) == mind)
                           {
                               count++;
                           }
                       }
                    }
                    else
                    {
                        count = 1;
                        miny = int.Parse(s[2]);
                        minm = int.Parse(s[1]);
                        mind = int.Parse(s[0]);
                        b = s1[0] + " " + s1[1];
                        
                    }
                    if(int.Parse(s[1]) < minm)
                        {
                            if(int.Parse(s[0]) < mind)
                            {
                                miny = int.Parse(s[2]);
                                minm = int.Parse(s[1]);
                                mind = int.Parse(s[0]);
                                b = s1[0] + " " + s1[1];
                            }
                        }
                }

            }

            if (count == 1)
            {
                Console.WriteLine(b);
            }
            else
            {
                Console.WriteLine(count);
            }

            Console.ReadLine();

        }
    }
}
