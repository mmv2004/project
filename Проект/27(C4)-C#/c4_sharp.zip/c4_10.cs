﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApplication4
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int min15 = int.MaxValue, min20 = int.MaxValue, min25 = int.MaxValue;
            int count15 = 1, count20 = 1, count25 = 1;
            for (int i = 0; i < n; i++)
            {
                string[] s = Console.ReadLine().Split(' ');

                if (int.Parse(s[2]) == 15)
                {
                    if (int.Parse(s[3]) == min15)
                    {
                        count15++;
                    }
                    if (int.Parse(s[3]) < min15)
                    {
                        min15 = int.Parse(s[3]);
                        count15 = 1;
                    }

                }
                if (int.Parse(s[2]) == 20)
                {
                    if (int.Parse(s[3]) == min20)
                    {
                        count20++;
                    }
                    if (int.Parse(s[3]) < min20)
                    {
                        min20 = int.Parse(s[3]);
                        count20 = 1;
                    }

                }
                if (int.Parse(s[2]) == 25)
                {
                    if (int.Parse(s[3]) == min25)
                    {
                        count25++;
                    }
                    if (int.Parse(s[3]) < min25)
                    {
                        min25 = int.Parse(s[3]);
                        count25 = 1;
                    }

                }
            }

            if (min15 == 5001)
            {
                Console.WriteLine("0");
            }
            else
            {
                Console.WriteLine(count15);
            }
            if (min20 == 5001)
            {
                Console.WriteLine("0");
            }
            else
            {
                Console.WriteLine(count20);
            }
            if (min25 == 5001)
            {
                Console.WriteLine("0");
            }
            else
            {
                Console.WriteLine(count25);
            }

            Console.Read();
        }
    }
}
